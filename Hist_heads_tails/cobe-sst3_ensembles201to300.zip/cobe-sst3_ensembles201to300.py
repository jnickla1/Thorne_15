from pathlib import Path
import netCDF4
import numpy as np
import os
import requests

def gridded_to_timeseries(array):
	array = np.array(array)
	if array.ndim == 4:
		if array.shape[3] == 1:
			array = array.reshape((array.shape[0],array.shape[1],array.shape[2]))
	if array.ndim < 3:
		raise TypeError("array must be a 3 dimensional array")
	# assumes an equirectangular grid where 1st dimension is longitude and 2nd dimension is latitude
	weight = (np.cos(np.arange(array.shape[1])/array.shape[1]*np.pi) - np.cos((np.arange(array.shape[1])+1)/array.shape[1]*np.pi))/2
	weight = np.transpose(np.tile(weight,(array.shape[2],array.shape[0],1)),[1,2,0])/array.shape[0]
	timeseries = np.divide(np.nansum(np.nansum(np.multiply(array,weight),axis=0),axis=0), \
		np.nansum(np.nansum(np.multiply(1-np.isnan(array).astype(int),weight),axis=0),axis=0))
	return timeseries

def days_in_month(years):
	years = np.array(years)
	years = np.round(np.reshape(years.copy(),(1,years.size),order='F'))
	output = np.transpose([[31,28,31,30,31,30,31,31,30,31,30,31]]) \
		+ np.transpose([[0,1,0,0,0,0,0,0,0,0,0,0]])*((years % 4 == 0).astype(int) - (years % 100 == 0).astype(int) + (years % 400 == 0).astype(int))
	return output

def monthly_to_annual_timeseries(matrix,first_year):
	if round(first_year,0) != first_year:
		raise TypeError("first year must be an integer")
	matrix = np.array(matrix)
	if matrix.ndim == 1:
		matrix = matrix.reshape((-1,1))
	if matrix.ndim != 2:
		raise TypeError("first input must be a 2 dimensional array")
	matrix_reshaped = matrix[:(matrix.shape[0]//12)*12].reshape(12,matrix.shape[0]//12,matrix.shape[1],order='F')
	years = np.arange(first_year,first_year+matrix.shape[0]//12)
	month_weights = days_in_month(years).astype(float)
	month_weights = np.divide(month_weights,np.sum(month_weights,axis=0)).reshape(12,matrix.shape[0]//12,1,order='F')
	annualized_matrix = np.sum(np.multiply(matrix_reshaped,month_weights),axis=0).reshape(-1,matrix.shape[1])
	return annualized_matrix

data_file_dir = Path(__file__).resolve().parent.parent

delete_large_data_files = True # storing COBE-SST3 gridded ensembles requires 12 TB of data
start_year = 1890
end_year = 2020
np.savetxt(data_file_dir / "COBE-SST3_ensembles201to300.csv", np.arange(1850,end_year+1).reshape(-1,1), fmt='%.16f', delimiter=",")
for ensemble_member in range(200,300):
    output = np.loadtxt(data_file_dir / "COBE-SST3_ensembles201to300.csv", delimiter=",").reshape(end_year-1850+1,-1)
    new_ensemble_values = np.zeros((end_year-start_year+1,1))
    for year in range(start_year,end_year+1):
        output_path = data_file_dir / f'cobe-sst3.m{ensemble_member+1:03d}.{year}.nc'
        if not Path(output_path).exists():
            url = f'https://climate.mri-jma.go.jp/pub/archives/Ishii-et-al_COBE-SST3/cobe-sst3/perturb/m{ensemble_member+1:03d}/cobe-sst3.m{ensemble_member+1:03d}.{year}.nc'
            try:
                # Send a GET request to the URL with stream enabled
                with requests.get(url, stream=True) as response:
                    response.raise_for_status() # Raise an exception for HTTP errors

                    # Open the output file in binary write mode
                    with open(output_path, 'wb') as file:
                        # Write data to file in chunks
                        for chunk in response.iter_content(chunk_size=8192):
                            if chunk:# Filter out keep-alive chunks
                                file.write(chunk)
                print(f"File downloaded successfully: {output_path}")
            except requests.exceptions.RequestException as e:
                print(f"Failed to download file: {e}")
        data_file = netCDF4.Dataset(output_path)
        data = np.transpose(np.ma.getdata(data_file.variables['sst']).data)
        data_file.close()
        if delete_large_data_files:
            os.remove(output_path)
        data[data > 999] = np.nan
        new_ensemble_values[year-start_year,0] = np.mean(gridded_to_timeseries(data),axis=0) #ensemble provides daily data
    #COBE-SST3 uses 1890 perturbations for years prior to 1890
    new_ensemble_values = np.append(np.kron(np.ones((40,1)),new_ensemble_values[0,0]),new_ensemble_values).reshape(-1,1)
    np.savetxt(data_file_dir / "COBE-SST3_ensembles201to300.csv", np.concatenate((output,new_ensemble_values),axis=1), fmt='%.16f', delimiter=",")
    print(f"Completed ensemble {ensemble_member+1}")
